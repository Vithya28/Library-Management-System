CREATE DATABASE lms
use lms

CREATE TABLE `book` (
  `Book_ID` int NOT NULL AUTO_INCREMENT,
  `Book_Title` varchar(150) NOT NULL,
  `Book_Author` varchar(150) NOT NULL,
  `Availabilty` varchar(45) NOT NULL,
  PRIMARY KEY (`Book_ID`)
)  AUTO_INCREMENT=1;

CREATE TABLE `member` (
  `Member_ID` int NOT NULL AUTO_INCREMENT,
  `Member_Name` varchar(150) NOT NULL,
  `Password` varchar(45) NOT NULL DEFAULT 'abc123',
  `Email_ID` varchar(150) NOT NULL,
  `Books_Taken` varchar(45) DEFAULT NULL,
  `Member_Type` varchar(45) NOT NULL,
  PRIMARY KEY (`Member_ID`),
  UNIQUE KEY `Email_ID_UNIQUE` (`Email_ID`)
)  AUTO_INCREMENT=1;

CREATE TABLE `transaction` (
  `Transaction_ID` int NOT NULL AUTO_INCREMENT,
  `Book_ID` int NOT NULL,
  `Member_ID` int NOT NULL,
  `Borrow_Date` varchar(60) NOT NULL,
  `Dueback` varchar(60) NOT NULL,
  `Status` varchar(60) NOT NULL,
  `Actual_return_date` varchar(45) NOT NULL,
  PRIMARY KEY (`Transaction_ID`)
) AUTO_INCREMENT=1;

