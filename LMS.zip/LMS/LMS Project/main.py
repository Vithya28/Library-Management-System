from tabulate import tabulate
import mysql.connector
import os
import datetime
import timedelta


con = mysql.connector.connect(host="localhost", user="root", password="abc123", database="lms")


def Mainmenu():
    print("---------- Main Menu ----------")
    print("1.Member SignUp")
    print("2.Member SignIn")
    print("3.Admin SignIn")
    print("4.Exit")
    choice = int(input("Enter The Choice: "))
    if choice == 1:
        print("---------- Member SignUp ----------")
        mem_name = input("Enter The Member Name: ")
        mem_type = "Student"  # input("Enter the Member Type: ")
        mem_email = input("Enter The Member Email ID: ")
        # books_taken = "0"
        insertMember(mem_name, mem_type, mem_email)
    if choice == 2:
        print("---------- Member SignIn ----------")
        mem_email = input("Enter The Member Email ID: ")
        mem_password = input("Enter The Password: ")
        Validsignin_member(mem_email, mem_password)
    if choice == 3:
        print("---------- Admin SignIn ----------")
        admin_email = input("Enter The Admin Email ID: ")
        admin_password = input("Enter The Admin Password: ")
        Validsignin_admin(admin_email, admin_password)
    if choice == 4:
        print("---------- Exit ----------")
        quit()

def insertMember(mem_name, mem_type, mem_email):
    books_taken = "0"
    res = con.cursor()
    sql = "insert into member(Member_Name,Email_ID,Books_Taken,Member_Type)  values (%s,%s,%s,%s)"
    member = (mem_name, mem_email, books_taken, mem_type)
    res.execute(sql, member)
    con.commit()
    print("Member Created Successfully!")

def insertBook(book_title, book_author):
    book_availability = "True"
    res = con.cursor()
    sql = "insert into book(BooK_Title,Book_Author,Availabilty)  values (%s,%s,%s)"
    book = (book_title, book_author, book_availability)
    res.execute(sql, book)
    con.commit()
    print("Book Added Successfully!")


def Validsignin_member(email, password):
    res = con.cursor()
    sql = "select count(*) as r from member where Email_ID=%s and Password=%s"
    validemail = (email, password)
    res.execute(sql, validemail)
    result = res.fetchall()
    res = result
    # print(result)
    if res[0][0] == 1:
        print("Member Signed In Successfully!")
        Signinsucess_member()
    else:
        print("Invalid EmailID And Password")


def Validsignin_admin(email, password):
    res = con.cursor()
    sql = "select count(*) as r from member where Email_ID=%s and Password=%s"
    validemail = (email, password)
    res.execute(sql, validemail)
    result = res.fetchall()
    res = result
    # print(result)
    if res[0][0] == 1:
        print("Admin Signed In Successfully!")
        Signinsucess_admin()
    else:
        print("Invalid EmailID And Password")


def Searchbookname(book_title):
    res = con.cursor()
    sql = "select count(*) as r from book where Book_Title=%s and Availabilty = %s"

    booksearch = (book_title, "True")
    res.execute(sql, booksearch)
    result = res.fetchall()
    res = result
    # print(res)
    # print(result)
    if res[0][0] == 1:
        print("Book Found!")
    else:
        print("Book Not Found!")

def Getmemberid(membername_bb):
    res = con.cursor()
    Member_Type = "Student"
    sql = "select Member_ID from member where Member_Name =%s and Member_Type = %s and CAST(Books_Taken AS UNSIGNED) <= 3"
    bookstaken = (membername_bb, Member_Type)
    res.execute(sql, bookstaken)
    result = res.fetchall()
    res = result
    # print(res)
    if not res:
        print("Borrow Limit Reached!")
        return 0
    return res[0][0]

def Getbookid(bookname_bb):
    res = con.cursor()
    Availability = "True"
    sql = "select Book_ID from book where Book_Title =%s and Availabilty =%s"
    bookavailability = (bookname_bb, Availability)
    res.execute(sql, bookavailability)
    result = res.fetchall()
    res = result
    if not res:
        print("Book Is Not Available!")
        return 0
    return res[0][0]

def Returnbookid(bookname_bb):
    res = con.cursor()
    Availability = "False"
    sql = "select Book_ID from book where Book_Title =%s and Availabilty =%s"
    bookavailability = (bookname_bb, Availability)
    res.execute(sql, bookavailability)
    result = res.fetchall()
    res = result
    if not res:
        print("Book Is Not Available!")
        return 0
    return res[0][0]

def InsertTransaction(book_id,member_id):
    Status = "Borrowed"
    actual_return = ""
    from datetime import datetime
    borrow_date1 = datetime.now()
    borrow_date = borrow_date1.strftime("%d/%m/%Y %H:%M:%S")
    from datetime import timedelta
    dueback_date1 = borrow_date1 + timedelta(days=10)
    dueback_date = dueback_date1.strftime("%d/%m/%Y %H:%M:%S")

    res = con.cursor()
    sql = "insert into transaction(Book_ID,Member_ID,Borrow_Date,Dueback,Status,Actual_return_date) values (%s,%s,%s,%s,%s,%s)"
    transaction = (book_id, member_id, borrow_date, dueback_date, Status, actual_return)
    res.execute(sql, transaction)

    member_type = "Student"
    sql = "update member set Books_Taken = CAST(Books_Taken AS UNSIGNED) + 1  where Member_ID = %s and Member_Type =%s"
    member = (member_id, member_type)
    res.execute(sql, member)

    Availability = "True"
    sql = "update book set Availabilty ='False' where Book_ID =%s and Availabilty =%s"
    book = (book_id, Availability)
    res.execute(sql, book)
    con.commit()
    print("Book Borrowed Successfully!")

def Signinsucess_member():
    while True:
        print("1.Search Book Status")
        print("2.Borrow Book ")
        print("3.Go Back To Main Menu")
        print("4.Exit")
        choice1 = int(input("Enter The Choice: "))
        if choice1 == 1:
            print("---------- Search Book Status ----------")
            getbookname = input("Enter The Book Name: ")
            Searchbookname(getbookname)
        if choice1 == 2:
            print("---------- Borrow Book ----------")
            membername_bb = input("Enter The Member Name To Borrow A Book: ")
            member_id = Getmemberid(membername_bb)
            if member_id > 0:
                bookname_bb = input("Enter The Book Name: ")
                book_id = Getbookid(bookname_bb)
                if book_id > 0:
                    InsertTransaction(book_id, member_id)
                else:
                    Mainmenu()
            else:
                Mainmenu()
        if choice1 == 3:
            Mainmenu()
        if choice1 == 4:
            quit()

def AdminCheckReturnBook( bookid_rb,memberid_rb):
    res = con.cursor()
    sql = "select count(*) from transaction where Book_ID = %s and Member_ID = %s and Status ='Borrowed'"
    returnbook = (bookid_rb,memberid_rb)
    res.execute(sql, returnbook)
    result = res.fetchall()
    res = result
    # print(res)
    if res[0][0] == 0:
        print("No Return For This Member")
        return 0
    return res[0][0]

def ReturnBook(book_id,member_id):

    from datetime import datetime
    actualreturn_date1 = datetime.now()
    actualreturn_date = actualreturn_date1.strftime("%d/%m/%Y %H:%M:%S")

    res = con.cursor()
    sql = "update transaction set Actual_return_date =%s where Book_ID = %s and Member_ID = %s and Status = 'Borrowed'"
    updatetransaction = (actualreturn_date, book_id, member_id)
    res.execute(sql, updatetransaction)

    member_type = "Student"
    sql = "update member set Books_Taken = CAST(Books_Taken AS UNSIGNED) - 1  where Member_ID = %s and Member_Type =%s"
    member = (member_id, member_type)
    res.execute(sql, member)

    Availability = "False"
    sql = "update book set Availabilty ='True' where Book_ID =%s and Availabilty =%s"
    book = (book_id, Availability)
    res.execute(sql, book)
    con.commit()
    print("Book Returned Successfully!")



def Signinsucess_admin():
    while True:
        print("1.Add Books")
        print("2.Return Book")
        print("3.Go Back To Main Menu")
        print("4.Exit")
        choice1 = int(input("Enter The Choice: "))
        if choice1 == 1:
            print("---------- Add Book: ----------")
            book_title = input("Enter The Book Title: ")
            book_author = input("Enter The Book Author: ")
            insertBook(book_title, book_author)
        if choice1 == 2:
            print("---------- Return Book: ----------")
            membername_rb = input("Enter The Member Name For Return: ")
            memberid_rb = Getmemberid(membername_rb)

            if memberid_rb > 0:
                bookname_rb = input("Enter The Book Name For Return: ")
                bookid_rb = Returnbookid(bookname_rb)

                if bookid_rb > 0:
                    check_return = AdminCheckReturnBook(bookid_rb, memberid_rb)
                    if check_return > 0:
                        ReturnBook(bookid_rb, memberid_rb)
                    else:
                        Mainmenu()
                else:
                    Mainmenu()
            else:
                Mainmenu()
        if choice1 == 3:
            Mainmenu()
        if choice1 == 4:
            quit()
while True:
    Mainmenu()
